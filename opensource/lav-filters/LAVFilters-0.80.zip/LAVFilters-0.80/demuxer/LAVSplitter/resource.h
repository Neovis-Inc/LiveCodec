//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LAVSplitter.rc
//
#define IDD_PROPPAGE_LAVFSETTINGS       9
#define IDD_PROPPAGE_FORMATS            10
#define IDS_PAGE_TITLE                  101
#define IDS_SUBMODE_NO_SUBS             102
#define IDI_ICON1                       103
#define IDS_SUBMODE_FORCED_SUBS         104
#define IDS_SUBMODE_DEFAULT             105
#define IDS_SUBMODE_ADVANCED            106
#define IDS_INPUT_FORMATS               107
#define IDC_LBL_PREF_LANG               1001
#define IDC_PREF_LANG                   1002
#define IDC_LBL_PREF_LANG_AUDIO         1003
#define IDC_PREF_LANG_SUBS              1004
#define IDC_LBL_PREF_LANG_SUBS          1005
#define IDC_SUBTITLE_MODE               1006
#define IDC_LBL_SUBMODE                 1007
#define IDC_VC1TIMESTAMP                1009
#define IDC_SUBSTREAMS                  1010
#define IDC_DEMUXER_SETTINGS            1011
#define IDC_SPLITTER_FOOTER             1012
#define IDC_FORMATS                     1016
#define IDC_LBL_INPUT                   1017
#define IDC_CUR_INPUT                   1018
#define IDC_LBL_FORMATS                 1019
#define IDC_BD_SUBS                     1020
#define IDC_BD_SEPARATE_FORCED_SUBS     1021
#define IDC_BD_ONLY_FORCED_SUBS         1022
#define IDC_STREAM_SWITCH_REMOVE_AUDIO  1024
#define IDC_SUBTITLE_NOTE               1025
#define IDC_IMPAIRED_AUDIO              1026
#define IDC_QUEUE_SETTINGS              1027
#define IDC_LBL_QUEUE_MEM               1028
#define IDC_QUEUE_MEM                   1029
#define IDC_QUEUE_MEM_SPIN              1030
#define IDC_TRAYICON                    1031
#define IDC_SELECT_AUDIO_QUALITY        1032
#define IDC_FMT_SETTINGS                1033
#define IDC_MKV_EXTERNAL                1034
#define IDC_NETWORK_SETTINGS            1035
#define IDC_LBL_STREAM_BUFFER           1036
#define IDC_STREAM_ANADUR               1037
#define IDC_STREAM_ANADUR_SPIN          1038
#define IDC_LBL_QUEUE_PACKETS           1039
#define IDC_QUEUE_PACKETS               1040
#define IDC_QUEUE_PACKETS_SPIN          1041
#define IDC_STREAM_SWITCH_RESELECT_SUBS 1042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
