#ifndef _AVS_ARCH_H_
#define _AVS_ARCH_H_

#define       AVS_ARCH          i386	    	// e.g. i386

#endif  //  _AVS_ARCH_H_
